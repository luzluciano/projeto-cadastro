# APIs de Usuários e Autenticação

## Sistema de Permissões

O sistema agora implementa controle de acesso baseado em grupos/perfis. Consulte [GRUPOS-PERMISSOES.md](./GRUPOS-PERMISSOES.md) para detalhes completos sobre grupos e permissões.

## Autenticação

### Login
**POST** `/api/login`

Autentica um usuário e retorna um token JWT.

**Body:**
```json
{
  "usuario": "admin",
  "senha": "admin123"
}
```

**Resposta de Sucesso:**
```json
{
  "success": true,
  "message": "Login realizado com sucesso",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "usuario": {
      "id": 1,
      "usuario": "admin",
      "nome": "Administrador",
      "permissions": ["usuarios.criar", "usuarios.listar", "usuarios.editar", "usuarios.deletar", "..."]
    }
  }
}
```

### Verificar Token
**GET** `/api/verify-token`

Verifica se o token JWT é válido.

**Headers:**
```
Authorization: Bearer <token>
```

**Resposta de Sucesso:**
```json
{
  "success": true,
  "message": "Token válido",
  "data": {
    "usuario": {
      "id": 1,
      "usuario": "admin",
      "nome": "Administrador",
      "permissions": ["usuarios.criar", "usuarios.listar", "usuarios.editar", "usuarios.deletar", "..."]
    }
  }
}
```

## CRUD de Usuários

> **Nota:** Todas as rotas de usuários agora requerem permissões específicas (não apenas autenticação).
> - **usuarios.criar** - Para criar usuários
> - **usuarios.listar** - Para listar/visualizar usuários
> - **usuarios.editar** - Para editar usuários
> - **usuarios.deletar** - Para deletar usuários

### Criar Usuário
**POST** `/api/usuarios`

**Body:**
```json
{
  "usuario": "novo_usuario",
  "senha": "senha123",
  "nome": "Nome do Usuário"
}
```

**Resposta de Sucesso:**
```json
{
  "success": true,
  "message": "Usuário criado com sucesso",
  "data": {
    "id": 2,
    "usuario": "novo_usuario",
    "nome": "Nome do Usuário",
    "created_at": "2024-12-07T10:00:00.000Z",
    "ativo": true
  }
}
```

### Listar Usuários
**GET** `/api/usuarios`

**Resposta de Sucesso:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "usuario": "admin",
      "nome": "Administrador",
      "created_at": "2024-12-07T09:00:00.000Z",
      "updated_at": "2024-12-07T09:00:00.000Z",
      "ativo": true
    },
    {
      "id": 2,
      "usuario": "novo_usuario",
      "nome": "Nome do Usuário",
      "created_at": "2024-12-07T10:00:00.000Z",
      "updated_at": "2024-12-07T10:00:00.000Z",
      "ativo": true
    }
  ]
}
```

### Obter Usuário por ID
**GET** `/api/usuarios/:id`

**Resposta de Sucesso:**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "usuario": "admin",
    "nome": "Administrador",
    "created_at": "2024-12-07T09:00:00.000Z",
    "updated_at": "2024-12-07T09:00:00.000Z",
    "ativo": true
  }
}
```

### Atualizar Usuário
**PUT** `/api/usuarios/:id`

**Body (todos os campos são opcionais):**
```json
{
  "usuario": "novo_nome_usuario",
  "senha": "nova_senha123",
  "nome": "Novo Nome",
  "ativo": false
}
```

**Resposta de Sucesso:**
```json
{
  "success": true,
  "message": "Usuário atualizado com sucesso",
  "data": {
    "id": 2,
    "usuario": "novo_nome_usuario",
    "nome": "Novo Nome",
    "created_at": "2024-12-07T10:00:00.000Z",
    "updated_at": "2024-12-07T11:00:00.000Z",
    "ativo": false
  }
}
```

### Deletar Usuário
**DELETE** `/api/usuarios/:id`

> **Nota:** Não é possível deletar o próprio usuário.

**Resposta de Sucesso:**
```json
{
  "success": true,
  "message": "Usuário deletado com sucesso",
  "data": {
    "id": 2,
    "usuario": "usuario_deletado",
    "nome": "Nome do Usuário"
  }
}
```

## Códigos de Erro Comuns

- **400** - Dados inválidos ou faltantes
- **401** - Token inválido ou ausente / Credenciais inválidas
- **404** - Usuário não encontrado
- **500** - Erro interno do servidor

## Estrutura da Tabela de Usuários

```sql
CREATE TABLE usuarios (
    id SERIAL PRIMARY KEY,
    usuario VARCHAR(50) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL, -- Hash da senha
    nome VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ativo BOOLEAN DEFAULT true
);
```

## Usuário Padrão

- **Usuário:** admin
- **Senha:** admin123
- **Nome:** Administrador
- **Grupo:** admin (todas as permissões)

Este usuário é criado automaticamente quando o servidor é iniciado pela primeira vez e é associado ao grupo 'admin' com todas as permissões do sistema.