require('dotenv').config();

const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = process.env.PORT || 3000;

// Configuração do banco PostgreSQL
const dbConfig = {
  connectionString: process.env.DATABASE_URL || 'postgresql://admin:admin@localhost:5432/crisma_db',
  ssl: process.env.NODE_ENV === 'production' ? {
    require: true,
    rejectUnauthorized: false
  } : false,
  max: parseInt(process.env.DB_MAX_CONNECTIONS) || 20,
  idleTimeoutMillis: parseInt(process.env.DB_IDLE_TIMEOUT) || 30000,
  connectionTimeoutMillis: parseInt(process.env.DB_CONNECTION_TIMEOUT) || 2000,
};

const pool = new Pool(dbConfig);

// Chave secreta para JWT (em produção, isso deve estar no .env)
const JWT_SECRET = process.env.JWT_SECRET || 'chave_secreta_muito_segura_12345';

// Configuração do Multer para upload de arquivos
const uploadDir = path.join(__dirname, 'uploads');
fs.ensureDirSync(uploadDir);

const storage = multer.memoryStorage();
////#
//const storage = multer.diskStorage({
//  destination: (req, file, cb) => {
//    cb(null, uploadDir);
//  },
//  filename: (req, file, cb) => {
    // Gerar nome único: timestamp_originalname
////    const uniqueName = Date.now() + '_' + file.originalname;
//    cb(null, uniqueName);
 // }
//});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB máximo
  },
  fileFilter: (req, file, cb) => {
    // Permitir apenas PDF, JPG, PNG
    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Tipo de arquivo não permitido. Use apenas PDF, JPG ou PNG.'));
    }
  }
});

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
// Servir arquivos estáticos da pasta uploads
app.use('/uploads', express.static(uploadDir));

// Testar conexão inicial
pool.on('connect', () => {
  console.log('✅ Conectado ao PostgreSQL');
});

pool.on('error', (err) => {
  console.error('❌ Erro na conexão com PostgreSQL:', err);
});

// ===== FUNÇÕES AUXILIARES =====

// Função para converter linha do banco para objeto frontend
function convertRowToInscricao(row) {
  return {
    tipoInscricao: row.tipo_inscricao,
    id: row.id,
    email: row.email,
    status: {
      atual: row.ultimo_status || 'Não definido',
      observacao: row.ultimo_status_obs || '',
      dataAtualizacao: row.ultimo_status_data || null
    },
    nomeCompleto: row.nome_completo,
    dataNascimento: row.data_nascimento,
    naturalidade: row.naturalidade,
    sexo: row.sexo,
    endereco: row.endereco,
    batizado: row.batizado,
    paroquiaBatismo: row.paroquia_batismo,
    dioceseBatismo: row.diocese_batismo,
    comunhao: row.comunhao === true ? 'Sim' : (row.comunhao === false ? 'Não' : null),
    paroquiaComunhao: row.paroquia_comunhao,
    dioceseComunhao: row.diocese_comunhao,
    telefoneWhatsApp: row.telefone_whatsapp,
    emailContato: row.email_contato,
    nomePai: row.nome_pai,
    estadoCivilPai: row.estado_civil_pai,
    naturalidadePai: row.naturalidade_pai,
    nomeMae: row.nome_mae,
    estadoCivilMae: row.estado_civil_mae,
    naturalidadeMae: row.naturalidade_mae,
    paisCasadosIgreja: row.pais_casados_igreja,
    paroquiaCasamentoPais: row.paroquia_casamento_pais,
    dioceseCasamentoPais: row.diocese_casamento_pais,
    nomePadrinhoMadrinha: row.nome_padrinho_madrinha,
    padrinhoCrismado: row.padrinho_crismado,
    dataInicioCurso: row.data_inicio_curso,
    comunidadeCurso: row.comunidade_curso,
    nomeCatequista: row.nome_catequista,
    horarioCurso: row.horario_curso,
    // Metadados dos arquivos BLOB
    documentoIdentidadeNome: row.documento_identidade_nome,
    documentoIdentidadeTipo: row.documento_identidade_tipo,
    documentoIdentidadeTamanho: row.documento_identidade_tamanho,
    certidaoBatismoNome: row.certidao_batismo_nome,
    certidaoBatismoTipo: row.certidao_batismo_tipo,
    certidaoBatismoTamanho: row.certidao_batismo_tamanho,
    createdAt: row.created_at,
    updatedAt: row.updated_at
  };
}

// ===== ROTAS DA API =====

// Teste de conexão
app.get('/api/test', async (req, res) => {
  try {
    const result = await pool.query('SELECT NOW() as current_time');
    console.log('✅ Teste de conexão bem-sucedido:', result.rows[0]);
    
    res.json({ 
      success: true, 
      message: 'Backend funcionando!',
      database: 'Conectado',
      timestamp: new Date().toISOString(),
      db_time: result.rows[0].current_time
    });
  } catch (error) {
    console.error('❌ Erro no teste de conexão:', error);
    res.status(500).json({ success: false, message: 'Erro de conexão' });
  }
});

// Endpoint para atualizar estrutura do banco para BLOB
app.post('/api/update-db-structure', async (req, res) => {
  try {
    console.log('🔄 Atualizando estrutura do banco para armazenar arquivos como BLOB...');

    // Remover colunas antigas de path se existirem
    await pool.query(`
      ALTER TABLE inscricoes_crisma 
      DROP COLUMN IF EXISTS documento_identidade_path,
      DROP COLUMN IF EXISTS certidao_batismo_path
    `);

    // Adicionar colunas para armazenar arquivos como BLOB
    await pool.query(`
      ALTER TABLE inscricoes_crisma 
      ADD COLUMN IF NOT EXISTS documento_identidade_data BYTEA,
      ADD COLUMN IF NOT EXISTS documento_identidade_nome VARCHAR(255),
      ADD COLUMN IF NOT EXISTS documento_identidade_tipo VARCHAR(100),
      ADD COLUMN IF NOT EXISTS documento_identidade_tamanho INTEGER,
      ADD COLUMN IF NOT EXISTS certidao_batismo_data BYTEA,
      ADD COLUMN IF NOT EXISTS certidao_batismo_nome VARCHAR(255),
      ADD COLUMN IF NOT EXISTS certidao_batismo_tipo VARCHAR(100),
      ADD COLUMN IF NOT EXISTS certidao_batismo_tamanho INTEGER
    `);

    console.log('✅ Estrutura do banco atualizada com sucesso!');

    res.json({
      success: true,
      message: 'Estrutura do banco atualizada para armazenar arquivos como BLOB'
    });

  } catch (error) {
    console.error('❌ Erro ao atualizar estrutura do banco:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao atualizar estrutura do banco',
      error: error.message
    });
  }
});

// Criar nova inscrição
app.post('/api/inscricoes', async (req, res) => {
  try {
    console.log('📝 Recebendo nova inscrição:', req.body);
    
    const dados = req.body;
    
    const query = `
      INSERT INTO inscricoes_crisma (
        email, nome_completo, data_nascimento, naturalidade, sexo, endereco,
        tipo_inscricao, batizado, paroquia_batismo, diocese_batismo, comunhao, paroquia_comunhao, diocese_comunhao,
        telefone_whatsapp, email_contato,
        nome_pai, estado_civil_pai, naturalidade_pai,
        nome_mae, estado_civil_mae, naturalidade_mae,
        pais_casados_igreja, paroquia_casamento_pais, diocese_casamento_pais,
        nome_padrinho_madrinha, padrinho_crismado,
        data_inicio_curso, comunidade_curso, nome_catequista, horario_curso
      ) VALUES (
        $1, $2, $3, $4, $5, $6,
        $7, $8, $9, $10, $11, $12, $13,
        $14, $15,
        $16, $17, $18,
        $19, $20, $21,
        $22, $23, $24,
        $25, $26,
        $27, $28, $29, $30
      ) RETURNING id, created_at;
    `;

    const values = [
      dados.email, dados.nomeCompleto, dados.dataNascimento, dados.naturalidade, dados.sexo, dados.endereco,
      dados.tipoInscricao, dados.batizado, dados.paroquiaBatismo, dados.dioceseBatismo, dados.comunhao, dados.paroquiaComunhao, dados.dioceseComunhao,
      dados.telefoneWhatsApp, dados.emailContato,
      dados.nomePai, dados.estadoCivilPai, dados.naturalidadePai,
      dados.nomeMae, dados.estadoCivilMae, dados.naturalidadeMae,
      dados.paisCasadosIgreja, dados.paroquiaCasamentoPais, dados.dioceseCasamentoPais,
      dados.nomePadrinhoMadrinha, dados.padrinhoCrismado,
      dados.dataInicioCurso, dados.comunidadeCurso, dados.nomeCatequista, dados.horarioCurso
    ];

    const result = await pool.query(query, values);
    const novaInscricao = result.rows[0];
    
    // Criar registro de status inicial
    const statusQuery = `
      INSERT INTO status_controle (inscricao_id, status, observacao, data_atualizacao)
      VALUES ($1, 'Em Andamento', 'Cadastro inicial', CURRENT_TIMESTAMP)
    `;
    await pool.query(statusQuery, [novaInscricao.id]);
    
    res.json({
      success: true,
      message: 'Inscrição salva com sucesso!',
      data: novaInscricao
    });
    
    console.log('✅ Inscrição salva com ID:', novaInscricao.id);
  } catch (error) {
    console.error('❌ Erro ao salvar inscrição:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao salvar inscrição',
      error: error.message,
      details: error.detail || error.hint || 'Verifique se o banco de dados está configurado corretamente'
    });
  }
});

// Buscar inscrições com filtros
app.get('/api/inscricoes', async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 100;
    const offset = parseInt(req.query.offset) || 0;
    
    // Construir query com filtros
    let whereConditions = [];
    let queryParams = [];
    let paramIndex = 1;
    
    // Filtros disponíveis
    if (req.query.email) {
      whereConditions.push(`email ILIKE $${paramIndex}`);
      queryParams.push(`%${req.query.email}%`);
      paramIndex++;
    }
    
    if (req.query.nomeCompleto) {
      whereConditions.push(`nome_completo ILIKE $${paramIndex}`);
      queryParams.push(`%${req.query.nomeCompleto}%`);
      paramIndex++;
    }
    
    if (req.query.comunidadeCurso) {
      whereConditions.push(`comunidade_curso ILIKE $${paramIndex}`);
      queryParams.push(`%${req.query.comunidadeCurso}%`);
      paramIndex++;
    }
    
    if (req.query.sexo) {
      whereConditions.push(`sexo = $${paramIndex}`);
      queryParams.push(req.query.sexo);
      paramIndex++;
    }
    
    if (req.query.batizado) {
      const batizadoValue = req.query.batizado === 'true';
      whereConditions.push(`batizado = $${paramIndex}`);
      queryParams.push(batizadoValue);
      paramIndex++;
    }
    
    if (req.query.dataInicio) {
      whereConditions.push(`data_nascimento >= $${paramIndex}`);
      queryParams.push(req.query.dataInicio);
      paramIndex++;
    }
    
    if (req.query.dataFim) {
      whereConditions.push(`data_nascimento <= $${paramIndex}`);
      queryParams.push(req.query.dataFim);
      paramIndex++;
    }
    
    // Construir query final
    let query = `
      SELECT 
        i.*,
        sh.status as ultimo_status,
        sh.observacao as ultimo_status_obs,
        sh.data_atualizacao as ultimo_status_data
      FROM inscricoes_crisma i
      LEFT JOIN (
        SELECT DISTINCT ON (inscricao_id) 
          inscricao_id,
          status,
          observacao,
          data_atualizacao
        FROM status_historico
        ORDER BY inscricao_id, created_at DESC
      ) sh ON i.id = sh.inscricao_id
    `;
    
    if (whereConditions.length > 0) {
      query += ' WHERE ' + whereConditions.join(' AND ');
    }
    
    query += ` ORDER BY i.id DESC LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`;
    queryParams.push(limit, offset);
    
    console.log('🔍 Query de consulta:', query);
    console.log('📋 Parâmetros:', queryParams);
    
    const result = await pool.query(query, queryParams);
    
    // Converter campos para formato frontend usando função auxiliar
    const inscricoes = result.rows.map(row => convertRowToInscricao(row));
    
    // Log temporário para debug
    if (inscricoes.length > 0) {
      console.log('🔍 Debug - Primeira inscrição retornada:');
      console.log('- documentoIdentidadeNome:', inscricoes[0].documentoIdentidadeNome);
      console.log('- certidaoBatismoNome:', inscricoes[0].certidaoBatismoNome);
      console.log('- documentoIdentidadeTamanho:', inscricoes[0].documentoIdentidadeTamanho);
      console.log('- certidaoBatismoTamanho:', inscricoes[0].certidaoBatismoTamanho);
    }
    
    res.json(inscricoes);
    
  } catch (error) {
    console.error('❌ Erro ao buscar inscrições:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao buscar inscrições',
      error: error.message
    });
  }
});

// Buscar inscrição por ID
app.get('/api/inscricoes/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    const query = 'SELECT * FROM inscricoes_crisma WHERE id = $1';
    const result = await pool.query(query, [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Inscrição não encontrada'
      });
    }
    
    const row = result.rows[0];
    const inscricao = convertRowToInscricao(row);
    
    res.json(inscricao);
    
  } catch (error) {
    console.error('❌ Erro ao buscar inscrição:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao buscar inscrição',
      error: error.message
    });
  }
});

// Rota para executar migração do campo comunhao
app.post('/api/fix-comunhao', async (req, res) => {
  try {
    console.log('🔧 Executando correção do campo comunhao...');
    
    // Verificar se a restrição existe
    const checkConstraint = await pool.query(`
      SELECT constraint_name 
      FROM information_schema.table_constraints 
      WHERE table_name = 'inscricoes_crisma' 
      AND constraint_name = 'inscricoes_crisma_comunhao_check'
    `);
    
    if (checkConstraint.rows.length > 0) {
      // Remover a restrição
      await pool.query('ALTER TABLE inscricoes_crisma DROP CONSTRAINT inscricoes_crisma_comunhao_check');
      console.log('✅ Restrição comunhao_check removida');
    }
    
    // Alterar o tipo do campo para BOOLEAN
    await pool.query(`
      ALTER TABLE inscricoes_crisma ALTER COLUMN comunhao TYPE BOOLEAN USING 
        CASE 
          WHEN comunhao = 'Sim' THEN TRUE
          WHEN comunhao = 'Não' THEN FALSE
          ELSE NULL
        END
    `);
    console.log('✅ Campo comunhao alterado para BOOLEAN');
    
    // Definir valor padrão como NULL
    await pool.query('ALTER TABLE inscricoes_crisma ALTER COLUMN comunhao SET DEFAULT NULL');
    console.log('✅ Valor padrão definido como NULL');
    
    res.json({
      success: true,
      message: 'Campo comunhao corrigido com sucesso!',
      details: 'Agora aceita valores boolean (true/false/null)'
    });
    
  } catch (error) {
    console.error('❌ Erro na migração:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao corrigir campo comunhao',
      error: error.message
    });
  }
});

// Rota para verificar se a tabela existe
app.get('/api/check-table', async (req, res) => {
  try {
    const query = `
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'inscricoes_crisma'
      );
    `;
    
    const result = await pool.query(query);
    const tableExists = result.rows[0].exists;
    
    if (tableExists) {
      // Contar registros existentes
      const countResult = await pool.query('SELECT COUNT(*) FROM inscricoes_crisma');
      const count = parseInt(countResult.rows[0].count);
      
      res.json({
        success: true,
        tableExists: true,
        message: `Tabela 'inscricoes_crisma' existe com ${count} registros`,
        count: count
      });
    } else {
      res.json({
        success: false,
        tableExists: false,
        message: 'Tabela inscricoes_crisma não existe. Execute o script database/schema.sql'
      });
    }
  } catch (error) {
    console.error('❌ Erro ao verificar tabela:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao verificar tabela',
      error: error.message
    });
  }
});

// ===== ENDPOINTS PARA EDIÇÃO E EXCLUSÃO =====

// Rota para atualizar uma inscrição específica (PUT)
app.put('/api/inscricoes/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const dados = req.body;
    
    console.log(`🔄 Atualizando inscrição ID: ${id}`);
    console.log('📋 Dados recebidos:', dados);
    
    const query = `
      UPDATE inscricoes_crisma 
      SET 
        email = $1,
        nome_completo = $2,
        data_nascimento = $3,
        naturalidade = $4,
        sexo = $5,
        endereco = $6,
        tipo_inscricao = $7,
        batizado = $8,
        paroquia_batismo = $9,
        diocese_batismo = $10,
        comunhao = $11,
        paroquia_comunhao = $12,
        diocese_comunhao = $13,
        telefone_whatsapp = $14,
        email_contato = $15,
        nome_pai = $16,
        estado_civil_pai = $17,
        naturalidade_pai = $18,
        nome_mae = $19,
        estado_civil_mae = $20,
        naturalidade_mae = $21,
        pais_casados_igreja = $22,
        paroquia_casamento_pais = $23,
        diocese_casamento_pais = $24,
        nome_padrinho_madrinha = $25,
        padrinho_crismado = $26,
        data_inicio_curso = $27,
        comunidade_curso = $28,
        nome_catequista = $29,
        horario_curso = $30,
        updated_at = NOW()
      WHERE id = $31
      RETURNING *
    `;
    
    const values = [
      dados.email, dados.nomeCompleto, dados.dataNascimento, dados.naturalidade, dados.sexo, dados.endereco,
      dados.tipoInscricao, dados.batizado, dados.paroquiaBatismo, dados.dioceseBatismo, dados.comunhao, dados.paroquiaComunhao, dados.dioceseComunhao,
      dados.telefoneWhatsApp, dados.emailContato,
      dados.nomePai, dados.estadoCivilPai, dados.naturalidadePai,
      dados.nomeMae, dados.estadoCivilMae, dados.naturalidadeMae,
      dados.paisCasadosIgreja, dados.paroquiaCasamentoPais, dados.dioceseCasamentoPais,
      dados.nomePadrinhoMadrinha, dados.padrinhoCrismado,
      dados.dataInicioCurso, dados.comunidadeCurso, dados.nomeCatequista, dados.horarioCurso,
      id
    ];
    
    const result = await pool.query(query, values);
    
    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Inscrição não encontrada'
      });
    }
    
    console.log('✅ Inscrição atualizada com sucesso');
    
    res.json({
      success: true,
      message: 'Inscrição atualizada com sucesso!',
      data: convertRowToInscricao(result.rows[0])
    });
    
  } catch (error) {
    console.error('❌ Erro ao atualizar inscrição:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao atualizar inscrição',
      error: error.message
    });
  }
});

// Rota para excluir uma inscrição específica (DELETE)
app.delete('/api/inscricoes/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    console.log(`🗑️ Excluindo inscrição ID: ${id}`);
    
    // Primeiro, buscar os dados da inscrição antes de excluir
    const selectQuery = 'SELECT * FROM inscricoes_crisma WHERE id = $1';
    const selectResult = await pool.query(selectQuery, [id]);
    
    if (selectResult.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Inscrição não encontrada'
      });
    }
    
    const inscricao = selectResult.rows[0];
    
    // Excluir a inscrição
    const deleteQuery = 'DELETE FROM inscricoes_crisma WHERE id = $1';
    await pool.query(deleteQuery, [id]);
    
    console.log(`✅ Inscrição de "${inscricao.nome_completo}" excluída com sucesso`);
    
    res.json({
      success: true,
      message: `Inscrição de "${inscricao.nome_completo}" excluída com sucesso!`,
      deletedData: convertRowToInscricao(inscricao)
    });
    
  } catch (error) {
    console.error('❌ Erro ao excluir inscrição:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao excluir inscrição',
      error: error.message
    });
  }
});

// ===== ENDPOINT PARA UPLOAD DE ARQUIVOS =====

// Endpoint para upload de arquivos com dados da inscrição (salvando como BLOB)
app.post('/api/inscricoes-com-arquivos', upload.fields([
  { name: 'documentoIdentidade', maxCount: 1 },
  { name: 'certidaoBatismo', maxCount: 1 }
]), async (req, res) => {
  try {
    console.log('📄 Recebendo inscrição com arquivos...');
    console.log('📋 Dados recebidos:', req.body);
    console.log('📎 Arquivos recebidos:', req.files);

    const dados = JSON.parse(req.body.dadosInscricao);
    
    // Processar arquivos para BLOB
    let documentoIdentidadeData = null, docIdNome = null, docIdTipo = null, docIdTamanho = null;
    let certidaoBatismoData = null, certBatNome = null, certBatTipo = null, certBatTamanho = null;

    if (req.files['documentoIdentidade']) {
      const file = req.files['documentoIdentidade'][0];
      documentoIdentidadeData = file.buffer;
      docIdNome = file.originalname;
      docIdTipo = file.mimetype;
      docIdTamanho = file.size;
      // Remover arquivo temporário
      //fs.unlinkSync(file.path);
    }

    if (req.files['certidaoBatismo']) {
      const file = req.files['certidaoBatismo'][0];
      certidaoBatismoData = file.buffer;
      certBatNome = file.originalname;
      certBatTipo = file.mimetype;
      certBatTamanho = file.size;
      // Remover arquivo temporário
      //fs.unlinkSync(file.path);
    }

    // Query SQL atualizada com campos BLOB
    const query = `
      INSERT INTO inscricoes_crisma (
        email, nome_completo, data_nascimento, naturalidade, sexo, endereco,
        tipo_inscricao, batizado, paroquia_batismo, diocese_batismo, comunhao, paroquia_comunhao, diocese_comunhao,
        telefone_whatsapp, email_contato,
        nome_pai, estado_civil_pai, naturalidade_pai,
        nome_mae, estado_civil_mae, naturalidade_mae,
        pais_casados_igreja, paroquia_casamento_pais, diocese_casamento_pais,
        nome_padrinho_madrinha, padrinho_crismado,
        data_inicio_curso, comunidade_curso, nome_catequista, horario_curso,
        documento_identidade_data, documento_identidade_nome, documento_identidade_tipo, documento_identidade_tamanho,
        certidao_batismo_data, certidao_batismo_nome, certidao_batismo_tipo, certidao_batismo_tamanho
      ) VALUES (
        $1, $2, $3, $4, $5, $6,
        $7, $8, $9, $10, $11, $12, $13,
        $14, $15,
        $16, $17, $18,
        $19, $20, $21,
        $22, $23, $24,
        $25, $26,
        $27, $28, $29, $30,
        $31, $32, $33, $34,
        $35, $36, $37, $38
      ) RETURNING id, created_at;
    `;

    const values = [
      dados.email, dados.nomeCompleto, dados.dataNascimento, dados.naturalidade, dados.sexo, dados.endereco,
      dados.tipoInscricao, dados.batizado, dados.paroquiaBatismo, dados.dioceseBatismo, dados.comunhao, dados.paroquiaComunhao, dados.dioceseComunhao,
      dados.telefoneWhatsApp, dados.emailContato,
      dados.nomePai, dados.estadoCivilPai, dados.naturalidadePai,
      dados.nomeMae, dados.estadoCivilMae, dados.naturalidadeMae,
      dados.paisCasadosIgreja, dados.paroquiaCasamentoPais, dados.dioceseCasamentoPais,
      dados.nomePadrinhoMadrinha, dados.padrinhoCrismado,
      dados.dataInicioCurso, dados.comunidadeCurso, dados.nomeCatequista, dados.horarioCurso,
      documentoIdentidadeData, docIdNome, docIdTipo, docIdTamanho,
      certidaoBatismoData, certBatNome, certBatTipo, certBatTamanho
    ];

    const result = await pool.query(query, values);
    const novaInscricao = result.rows[0];

    // Criar registro de status inicial
    const statusQuery = `
      INSERT INTO status_controle (inscricao_id, status, observacao, data_atualizacao)
      VALUES ($1, 'Em Andamento', 'Cadastro inicial', CURRENT_TIMESTAMP)
    `;
    await pool.query(statusQuery, [novaInscricao.id]);

    console.log('✅ Inscrição criada com arquivos no banco:', {
      id: novaInscricao.id,
      documentoIdentidade: docIdNome || 'Não anexado',
      certidaoBatismo: certBatNome || 'Não anexado'
    });

    res.status(201).json({
      success: true,
      message: 'Inscrição criada com sucesso! Arquivos salvos no banco de dados.',
      data: {
        id: novaInscricao.id,
        created_at: novaInscricao.created_at,
        arquivos: {
          documentoIdentidade: docIdNome ? {
            nome: docIdNome,
            tipo: docIdTipo,
            tamanho: docIdTamanho
          } : null,
          certidaoBatismo: certBatNome ? {
            nome: certBatNome,
            tipo: certBatTipo,
            tamanho: certBatTamanho
          } : null
        }
      }
    });

  } catch (error) {
    console.error('❌ Erro ao criar inscrição com arquivos:', error);

    // Remover arquivos temporários se houve erro
    if (req.files) {
      Object.values(req.files).flat().forEach(file => {
        if (fs.existsSync(file.path)) {
          fs.unlinkSync(file.path);
        }
      });
    }

    res.status(500).json({
      success: false,
      message: 'Erro interno do servidor',
      error: error.message
    });
  }
});

// ===== ENDPOINT PARA DOWNLOAD DE ARQUIVOS DO BANCO =====

// Endpoint para baixar documento de identidade
app.get('/api/arquivo/documento-identidade/:id', async (req, res) => {
  try {
    const inscricaoId = req.params.id;
    
    const result = await pool.query(
      'SELECT documento_identidade_data, documento_identidade_nome, documento_identidade_tipo FROM inscricoes_crisma WHERE id = $1',
      [inscricaoId]
    );

    if (result.rows.length === 0 || !result.rows[0].documento_identidade_data) {
      return res.status(404).json({ success: false, message: 'Documento não encontrado' });
    }

    const arquivo = result.rows[0];
    
    res.setHeader('Content-Type', arquivo.documento_identidade_tipo);
    res.setHeader('Content-Disposition', `attachment; filename="${arquivo.documento_identidade_nome}"`);
    res.send(arquivo.documento_identidade_data);

  } catch (error) {
    console.error('❌ Erro ao baixar documento de identidade:', error);
    res.status(500).json({ success: false, message: 'Erro interno do servidor' });
  }
});

// Endpoint para salvar status de controle
app.post('/api/inscricoes/:id/status', async (req, res) => {
  try {
    const inscricaoId = req.params.id;
    const { status, observacao } = req.body;
    
    // Primeiro verificar se a inscrição existe
    const checkInscricao = await pool.query('SELECT id FROM inscricoes_crisma WHERE id = $1', [inscricaoId]);
    if (checkInscricao.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Inscrição não encontrada'
      });
    }

    // Iniciar uma transação
    const client = await pool.connect();
    try {
      await client.query('BEGIN');

      // Salvar novo status no histórico
      const timestamp = new Date().toISOString();
      
      const query = `
        INSERT INTO status_historico (
          inscricao_id, 
          status, 
          observacao, 
          data_atualizacao,
          created_at
        )
        VALUES ($1, $2, $3, $4, $4)
        RETURNING *;
      `;
      const result = await client.query(query, [inscricaoId, status, observacao, timestamp]);

      await client.query('COMMIT');
      
      res.json({
        success: true,
        message: 'Status atualizado com sucesso',
        data: result.rows[0]
      });
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }

  } catch (error) {
    console.error('❌ Erro ao atualizar status:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao atualizar status',
      error: error.message
    });
  }
});

// Endpoint para buscar histórico de status
app.get('/api/inscricoes/:id/status/historico', async (req, res) => {
  try {
    const inscricaoId = req.params.id;
    console.log('🔍 Buscando histórico para inscrição:', inscricaoId);
    
    const query = `
      SELECT 
        id, 
        inscricao_id, 
        status, 
        observacao, 
        data_atualizacao, 
        created_at
      FROM status_historico 
      WHERE inscricao_id = $1 
      ORDER BY created_at DESC, id DESC
    `;
    const result = await pool.query(query, [inscricaoId]);
    
    console.log('📊 Registros encontrados:', result.rows.length);
    
    // Converter snake_case para camelCase antes de enviar
    const historico = result.rows.map(row => {
      const item = {
        id: row.id,
        inscricaoId: row.inscricao_id,
        status: row.status,
        observacao: row.observacao,
        dataAtualizacao: row.data_atualizacao,
        createdAt: row.created_at
      };
      console.log('🔄 Item do histórico:', item);
      return item;
    });

    res.json(historico);
    
  } catch (error) {
    console.error('❌ Erro ao buscar histórico de status:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao buscar histórico de status',
      error: error.message
    });
  }
});

// Endpoint para buscar status de controle
app.get('/api/inscricoes/:id/status', async (req, res) => {
  try {
    const inscricaoId = req.params.id;
    
    const query = 'SELECT * FROM status_controle WHERE inscricao_id = $1';
    const result = await pool.query(query, [inscricaoId]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Status não encontrado'
      });
    }

    // Converter snake_case para camelCase antes de enviar
    const row = result.rows[0];
    const status = {
      id: row.id,
      inscricaoId: row.inscricao_id,
      status: row.status,
      observacao: row.observacao,
      dataAtualizacao: row.data_atualizacao
    };
    
    res.json(status);
    
  } catch (error) {
    console.error('❌ Erro ao buscar status:', error);
    res.status(500).json({
      success: false,
      message: 'Erro ao buscar status',
      error: error.message
    });
  }
});

// Endpoint para baixar certidão de batismo
app.get('/api/arquivo/certidao-batismo/:id', async (req, res) => {
  try {
    const inscricaoId = req.params.id;
    
    const result = await pool.query(
      'SELECT certidao_batismo_data, certidao_batismo_nome, certidao_batismo_tipo FROM inscricoes_crisma WHERE id = $1',
      [inscricaoId]
    );

    if (result.rows.length === 0 || !result.rows[0].certidao_batismo_data) {
      return res.status(404).json({ success: false, message: 'Documento não encontrado' });
    }

    const arquivo = result.rows[0];
    
    res.setHeader('Content-Type', arquivo.certidao_batismo_tipo);
    res.setHeader('Content-Disposition', `attachment; filename="${arquivo.certidao_batismo_nome}"`);
    res.send(arquivo.certidao_batismo_data);

  } catch (error) {
    console.error('❌ Erro ao baixar certidão de batismo:', error);
    res.status(500).json({ success: false, message: 'Erro interno do servidor' });
  }
});

// ===== MIDDLEWARE DE AUTENTICAÇÃO =====

// Função para obter permissões do usuário
async function getUserPermissions(userId) {
  try {
    const result = await pool.query(`
      SELECT DISTINCT unnest(ga.permissoes) as permissao
      FROM usuario_grupos ug
      JOIN grupos_acesso ga ON ug.grupo_id = ga.id
      WHERE ug.usuario_id = $1 AND ga.ativo = true
    `, [userId]);
    
    return result.rows.map(row => row.permissao);
  } catch (error) {
    console.error('Erro ao obter permissões:', error);
    return [];
  }
}

// Middleware para verificar JWT
function verifyToken(req, res, next) {
  const token = req.header('Authorization')?.replace('Bearer ', '');
  
  if (!token) {
    return res.status(401).json({ success: false, message: 'Token de acesso requerido' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    res.status(401).json({ success: false, message: 'Token inválido' });
  }
}

// Middleware para verificar permissões específicas
function requirePermission(permission) {
  return async (req, res, next) => {
    try {
      if (!req.user) {
        return res.status(401).json({ success: false, message: 'Usuário não autenticado' });
      }

      const permissions = await getUserPermissions(req.user.id);
      
      if (!permissions.includes(permission)) {
        return res.status(403).json({ 
          success: false, 
          message: `Permissão necessária: ${permission}` 
        });
      }

      req.userPermissions = permissions;
      next();
    } catch (error) {
      console.error('Erro ao verificar permissão:', error);
      res.status(500).json({ success: false, message: 'Erro interno do servidor' });
    }
  };
}

// ===== ROTAS DE AUTENTICAÇÃO =====

// Login de usuário
app.post('/api/login', async (req, res) => {
  try {
    const { usuario, senha } = req.body;

    if (!usuario || !senha) {
      return res.status(400).json({ 
        success: false, 
        message: 'Usuário e senha são obrigatórios' 
      });
    }

    // Buscar usuário no banco
    const result = await pool.query(
      'SELECT id, usuario, senha, nome, ativo FROM usuarios WHERE usuario = $1',
      [usuario]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ 
        success: false, 
        message: 'Usuário ou senha inválidos' 
      });
    }

    const user = result.rows[0];

    // Verificar se o usuário está ativo
    if (!user.ativo) {
      return res.status(401).json({ 
        success: false, 
        message: 'Usuário desativado' 
      });
    }

    // Verificar senha
    const senhaValida = await bcrypt.compare(senha, user.senha);
    if (!senhaValida) {
      return res.status(401).json({ 
        success: false, 
        message: 'Usuário ou senha inválidos' 
      });
    }

    // Obter permissões do usuário
    const permissions = await getUserPermissions(user.id);

    // Gerar token JWT
    const token = jwt.sign(
      { 
        id: user.id, 
        usuario: user.usuario, 
        nome: user.nome,
        permissions: permissions
      }, 
      JWT_SECRET, 
      { expiresIn: '24h' }
    );

    res.json({
      success: true,
      message: 'Login realizado com sucesso',
      data: {
        token,
        usuario: {
          id: user.id,
          usuario: user.usuario,
          nome: user.nome,
          permissions: permissions
        }
      }
    });

  } catch (error) {
    console.error('❌ Erro no login:', error);
    res.status(500).json({ success: false, message: 'Erro interno do servidor' });
  }
});

// ===== CRUD DE USUÁRIOS =====

// Criar usuário (requer permissão)
app.post('/api/usuarios', verifyToken, requirePermission('usuarios.criar'), async (req, res) => {
  try {
    const { usuario, senha, nome } = req.body;

    // Validações
    if (!usuario || !senha || !nome) {
      return res.status(400).json({ 
        success: false, 
        message: 'Usuário, senha e nome são obrigatórios' 
      });
    }

    if (senha.length < 6) {
      return res.status(400).json({ 
        success: false, 
        message: 'Senha deve ter pelo menos 6 caracteres' 
      });
    }

    // Verificar se usuário já existe
    const userExists = await pool.query(
      'SELECT id FROM usuarios WHERE usuario = $1',
      [usuario]
    );

    if (userExists.rows.length > 0) {
      return res.status(400).json({ 
        success: false, 
        message: 'Usuário já existe' 
      });
    }

    // Hash da senha
    const senhaHash = await bcrypt.hash(senha, 10);

    // Inserir usuário
    const result = await pool.query(
      'INSERT INTO usuarios (usuario, senha, nome) VALUES ($1, $2, $3) RETURNING id, usuario, nome, created_at, ativo',
      [usuario, senhaHash, nome]
    );

    res.status(201).json({
      success: true,
      message: 'Usuário criado com sucesso',
      data: result.rows[0]
    });

  } catch (error) {
    console.error('❌ Erro ao criar usuário:', error);
    res.status(500).json({ success: false, message: 'Erro interno do servidor' });
  }
});

// Listar usuários (requer permissão)
app.get('/api/usuarios', verifyToken, requirePermission('usuarios.listar'), async (req, res) => {
  try {
    const result = await pool.query(
      'SELECT id, usuario, nome, created_at, updated_at, ativo FROM usuarios ORDER BY nome'
    );

    res.json({
      success: true,
      data: result.rows
    });

  } catch (error) {
    console.error('❌ Erro ao listar usuários:', error);
    res.status(500).json({ success: false, message: 'Erro interno do servidor' });
  }
});

// Obter usuário por ID (requer permissão)
app.get('/api/usuarios/:id', verifyToken, requirePermission('usuarios.listar'), async (req, res) => {
  try {
    const { id } = req.params;

    const result = await pool.query(
      'SELECT id, usuario, nome, created_at, updated_at, ativo FROM usuarios WHERE id = $1',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ 
        success: false, 
        message: 'Usuário não encontrado' 
      });
    }

    res.json({
      success: true,
      data: result.rows[0]
    });

  } catch (error) {
    console.error('❌ Erro ao obter usuário:', error);
    res.status(500).json({ success: false, message: 'Erro interno do servidor' });
  }
});

// Atualizar usuário (requer permissão)
app.put('/api/usuarios/:id', verifyToken, requirePermission('usuarios.editar'), async (req, res) => {
  try {
    const { id } = req.params;
    const { usuario, senha, nome, ativo } = req.body;

    // Verificar se usuário existe
    const userExists = await pool.query(
      'SELECT id FROM usuarios WHERE id = $1',
      [id]
    );

    if (userExists.rows.length === 0) {
      return res.status(404).json({ 
        success: false, 
        message: 'Usuário não encontrado' 
      });
    }

    // Preparar campos para atualização
    let setClauses = [];
    let values = [];
    let paramCount = 1;

    if (usuario) {
      // Verificar se o novo nome de usuário não está em uso por outro usuário
      const userWithSameUsername = await pool.query(
        'SELECT id FROM usuarios WHERE usuario = $1 AND id != $2',
        [usuario, id]
      );

      if (userWithSameUsername.rows.length > 0) {
        return res.status(400).json({ 
          success: false, 
          message: 'Nome de usuário já está em uso' 
        });
      }

      setClauses.push(`usuario = $${paramCount}`);
      values.push(usuario);
      paramCount++;
    }

    if (senha) {
      if (senha.length < 6) {
        return res.status(400).json({ 
          success: false, 
          message: 'Senha deve ter pelo menos 6 caracteres' 
        });
      }
      const senhaHash = await bcrypt.hash(senha, 10);
      setClauses.push(`senha = $${paramCount}`);
      values.push(senhaHash);
      paramCount++;
    }

    if (nome) {
      setClauses.push(`nome = $${paramCount}`);
      values.push(nome);
      paramCount++;
    }

    if (typeof ativo === 'boolean') {
      setClauses.push(`ativo = $${paramCount}`);
      values.push(ativo);
      paramCount++;
    }

    if (setClauses.length === 0) {
      return res.status(400).json({ 
        success: false, 
        message: 'Nenhum campo para atualizar' 
      });
    }

    // Adicionar updated_at
    setClauses.push(`updated_at = CURRENT_TIMESTAMP`);

    // Adicionar ID no final
    values.push(id);

    const updateQuery = `
      UPDATE usuarios 
      SET ${setClauses.join(', ')} 
      WHERE id = $${paramCount}
      RETURNING id, usuario, nome, created_at, updated_at, ativo
    `;

    const result = await pool.query(updateQuery, values);

    res.json({
      success: true,
      message: 'Usuário atualizado com sucesso',
      data: result.rows[0]
    });

  } catch (error) {
    console.error('❌ Erro ao atualizar usuário:', error);
    res.status(500).json({ success: false, message: 'Erro interno do servidor' });
  }
});

// Deletar usuário (requer permissão)
app.delete('/api/usuarios/:id', verifyToken, requirePermission('usuarios.deletar'), async (req, res) => {
  try {
    const { id } = req.params;

    // Verificar se não está tentando deletar o próprio usuário
    if (req.user.id === parseInt(id)) {
      return res.status(400).json({ 
        success: false, 
        message: 'Você não pode deletar seu próprio usuário' 
      });
    }

    const result = await pool.query(
      'DELETE FROM usuarios WHERE id = $1 RETURNING id, usuario, nome',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ 
        success: false, 
        message: 'Usuário não encontrado' 
      });
    }

    res.json({
      success: true,
      message: 'Usuário deletado com sucesso',
      data: result.rows[0]
    });

  } catch (error) {
    console.error('❌ Erro ao deletar usuário:', error);
    res.status(500).json({ success: false, message: 'Erro interno do servidor' });
  }
});

// Rota para verificar token válido
app.get('/api/verify-token', verifyToken, async (req, res) => {
  try {
    const permissions = await getUserPermissions(req.user.id);
    
    res.json({
      success: true,
      message: 'Token válido',
      data: {
        usuario: {
          ...req.user,
          permissions: permissions
        }
      }
    });
  } catch (error) {
    console.error('Erro ao verificar token:', error);
    res.status(500).json({ success: false, message: 'Erro interno do servidor' });
  }
});

// ===== CRUD DE GRUPOS/PERFIS =====

// Listar grupos (requer permissão)
app.get('/api/grupos', verifyToken, requirePermission('grupos.listar'), async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT id, nome, descricao, permissoes, ativo, created_at, updated_at
      FROM grupos_acesso 
      ORDER BY nome
    `);

    res.json({
      success: true,
      data: result.rows
    });

  } catch (error) {
    console.error('❌ Erro ao listar grupos:', error);
    res.status(500).json({ success: false, message: 'Erro interno do servidor' });
  }
});

// Obter grupo por ID (requer permissão)
app.get('/api/grupos/:id', verifyToken, requirePermission('grupos.listar'), async (req, res) => {
  try {
    const { id } = req.params;

    const result = await pool.query(`
      SELECT id, nome, descricao, permissoes, ativo, created_at, updated_at
      FROM grupos_acesso 
      WHERE id = $1
    `, [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ 
        success: false, 
        message: 'Grupo não encontrado' 
      });
    }

    res.json({
      success: true,
      data: result.rows[0]
    });

  } catch (error) {
    console.error('❌ Erro ao obter grupo:', error);
    res.status(500).json({ success: false, message: 'Erro interno do servidor' });
  }
});

// Criar grupo (requer permissão)
app.post('/api/grupos', verifyToken, requirePermission('grupos.criar'), async (req, res) => {
  try {
    const { nome, descricao, permissoes } = req.body;

    // Validações
    if (!nome) {
      return res.status(400).json({ 
        success: false, 
        message: 'Nome do grupo é obrigatório' 
      });
    }

    if (!Array.isArray(permissoes)) {
      return res.status(400).json({ 
        success: false, 
        message: 'Permissões devem ser um array' 
      });
    }

    // Verificar se grupo já existe
    const groupExists = await pool.query(
      'SELECT id FROM grupos_acesso WHERE nome = $1',
      [nome]
    );

    if (groupExists.rows.length > 0) {
      return res.status(400).json({ 
        success: false, 
        message: 'Grupo já existe' 
      });
    }

    // Inserir grupo
    const result = await pool.query(
      'INSERT INTO grupos_acesso (nome, descricao, permissoes) VALUES ($1, $2, $3) RETURNING *',
      [nome, descricao, permissoes]
    );

    res.status(201).json({
      success: true,
      message: 'Grupo criado com sucesso',
      data: result.rows[0]
    });

  } catch (error) {
    console.error('❌ Erro ao criar grupo:', error);
    res.status(500).json({ success: false, message: 'Erro interno do servidor' });
  }
});

// Atualizar grupo (requer permissão)
app.put('/api/grupos/:id', verifyToken, requirePermission('grupos.editar'), async (req, res) => {
  try {
    const { id } = req.params;
    const { nome, descricao, permissoes, ativo } = req.body;

    // Verificar se grupo existe
    const groupExists = await pool.query(
      'SELECT id FROM grupos_acesso WHERE id = $1',
      [id]
    );

    if (groupExists.rows.length === 0) {
      return res.status(404).json({ 
        success: false, 
        message: 'Grupo não encontrado' 
      });
    }

    // Preparar campos para atualização
    let setClauses = [];
    let values = [];
    let paramCount = 1;

    if (nome) {
      // Verificar se o novo nome não está em uso por outro grupo
      const groupWithSameName = await pool.query(
        'SELECT id FROM grupos_acesso WHERE nome = $1 AND id != $2',
        [nome, id]
      );

      if (groupWithSameName.rows.length > 0) {
        return res.status(400).json({ 
          success: false, 
          message: 'Nome do grupo já está em uso' 
        });
      }

      setClauses.push(`nome = $${paramCount}`);
      values.push(nome);
      paramCount++;
    }

    if (descricao !== undefined) {
      setClauses.push(`descricao = $${paramCount}`);
      values.push(descricao);
      paramCount++;
    }

    if (Array.isArray(permissoes)) {
      setClauses.push(`permissoes = $${paramCount}`);
      values.push(permissoes);
      paramCount++;
    }

    if (typeof ativo === 'boolean') {
      setClauses.push(`ativo = $${paramCount}`);
      values.push(ativo);
      paramCount++;
    }

    if (setClauses.length === 0) {
      return res.status(400).json({ 
        success: false, 
        message: 'Nenhum campo para atualizar' 
      });
    }

    // Adicionar updated_at
    setClauses.push(`updated_at = CURRENT_TIMESTAMP`);

    // Adicionar ID no final
    values.push(id);

    const updateQuery = `
      UPDATE grupos_acesso 
      SET ${setClauses.join(', ')} 
      WHERE id = $${paramCount}
      RETURNING *
    `;

    const result = await pool.query(updateQuery, values);

    res.json({
      success: true,
      message: 'Grupo atualizado com sucesso',
      data: result.rows[0]
    });

  } catch (error) {
    console.error('❌ Erro ao atualizar grupo:', error);
    res.status(500).json({ success: false, message: 'Erro interno do servidor' });
  }
});

// Deletar grupo (requer permissão)
app.delete('/api/grupos/:id', verifyToken, requirePermission('grupos.deletar'), async (req, res) => {
  try {
    const { id } = req.params;

    // Verificar se é um dos grupos padrão (admin, operador, consulta)
    const defaultGroups = await pool.query(
      'SELECT nome FROM grupos_acesso WHERE id = $1 AND nome IN ($2, $3, $4)',
      [id, 'admin', 'operador', 'consulta']
    );

    if (defaultGroups.rows.length > 0) {
      return res.status(400).json({ 
        success: false, 
        message: 'Não é possível deletar grupos padrão do sistema' 
      });
    }

    const result = await pool.query(
      'DELETE FROM grupos_acesso WHERE id = $1 RETURNING id, nome, descricao',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ 
        success: false, 
        message: 'Grupo não encontrado' 
      });
    }

    res.json({
      success: true,
      message: 'Grupo deletado com sucesso',
      data: result.rows[0]
    });

  } catch (error) {
    console.error('❌ Erro ao deletar grupo:', error);
    res.status(500).json({ success: false, message: 'Erro interno do servidor' });
  }
});

// ===== GESTÃO DE USUÁRIO-GRUPOS =====

// Obter grupos de um usuário
app.get('/api/usuarios/:id/grupos', verifyToken, requirePermission('usuarios.listar'), async (req, res) => {
  try {
    const { id } = req.params;

    const result = await pool.query(`
      SELECT ga.id, ga.nome, ga.descricao, ga.permissoes, ug.created_at as vinculado_em
      FROM usuario_grupos ug
      JOIN grupos_acesso ga ON ug.grupo_id = ga.id
      WHERE ug.usuario_id = $1
      ORDER BY ga.nome
    `, [id]);

    res.json({
      success: true,
      data: result.rows
    });

  } catch (error) {
    console.error('❌ Erro ao obter grupos do usuário:', error);
    res.status(500).json({ success: false, message: 'Erro interno do servidor' });
  }
});

// Adicionar usuário a um grupo
app.post('/api/usuarios/:userId/grupos/:grupoId', verifyToken, requirePermission('usuarios.editar'), async (req, res) => {
  try {
    const { userId, grupoId } = req.params;

    // Verificar se usuário existe
    const userExists = await pool.query('SELECT id FROM usuarios WHERE id = $1', [userId]);
    if (userExists.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Usuário não encontrado' });
    }

    // Verificar se grupo existe
    const groupExists = await pool.query('SELECT id FROM grupos_acesso WHERE id = $1', [grupoId]);
    if (groupExists.rows.length === 0) {
      return res.status(404).json({ success: false, message: 'Grupo não encontrado' });
    }

    // Verificar se já está associado
    const alreadyExists = await pool.query(
      'SELECT id FROM usuario_grupos WHERE usuario_id = $1 AND grupo_id = $2',
      [userId, grupoId]
    );

    if (alreadyExists.rows.length > 0) {
      return res.status(400).json({ success: false, message: 'Usuário já pertence a este grupo' });
    }

    // Inserir associação
    await pool.query(
      'INSERT INTO usuario_grupos (usuario_id, grupo_id) VALUES ($1, $2)',
      [userId, grupoId]
    );

    res.json({
      success: true,
      message: 'Usuário adicionado ao grupo com sucesso'
    });

  } catch (error) {
    console.error('❌ Erro ao adicionar usuário ao grupo:', error);
    res.status(500).json({ success: false, message: 'Erro interno do servidor' });
  }
});

// Remover usuário de um grupo
app.delete('/api/usuarios/:userId/grupos/:grupoId', verifyToken, requirePermission('usuarios.editar'), async (req, res) => {
  try {
    const { userId, grupoId } = req.params;

    const result = await pool.query(
      'DELETE FROM usuario_grupos WHERE usuario_id = $1 AND grupo_id = $2 RETURNING *',
      [userId, grupoId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ 
        success: false, 
        message: 'Associação não encontrada' 
      });
    }

    res.json({
      success: true,
      message: 'Usuário removido do grupo com sucesso'
    });

  } catch (error) {
    console.error('❌ Erro ao remover usuário do grupo:', error);
    res.status(500).json({ success: false, message: 'Erro interno do servidor' });
  }
});

// Listar permissões disponíveis
app.get('/api/permissoes', verifyToken, requirePermission('grupos.listar'), async (req, res) => {
  try {
    const permissoesDisponiveis = [
      { categoria: 'usuarios', permissoes: ['usuarios.criar', 'usuarios.listar', 'usuarios.editar', 'usuarios.deletar'] },
      { categoria: 'inscricoes', permissoes: ['inscricoes.criar', 'inscricoes.listar', 'inscricoes.editar', 'inscricoes.deletar'] },
      { categoria: 'grupos', permissoes: ['grupos.criar', 'grupos.listar', 'grupos.editar', 'grupos.deletar'] },
      { categoria: 'sistema', permissoes: ['sistema.configurar'] }
    ];

    res.json({
      success: true,
      data: permissoesDisponiveis
    });

  } catch (error) {
    console.error('❌ Erro ao listar permissões:', error);
    res.status(500).json({ success: false, message: 'Erro interno do servidor' });
  }
});

// Função para atualizar estrutura do banco
async function atualizarEstruturaBanco() {
  try {
    console.log('🔄 Verificando/atualizando estrutura do banco...');

    // Verificar e adicionar coluna tipo_inscricao
    await pool.query(`
      DO $$ 
      BEGIN
        IF NOT EXISTS (
          SELECT 1 FROM information_schema.columns 
          WHERE table_name = 'inscricoes_crisma' 
          AND column_name = 'tipo_inscricao'
        ) THEN
          ALTER TABLE inscricoes_crisma
          ADD COLUMN tipo_inscricao VARCHAR(20) NOT NULL DEFAULT 'crisma';

          ALTER TABLE inscricoes_crisma
          ADD CONSTRAINT inscricoes_tipo_check 
          CHECK (tipo_inscricao IN ('catequese', 'catecumenato', 'crisma'));

          CREATE INDEX IF NOT EXISTS idx_inscricoes_tipo ON inscricoes_crisma(tipo_inscricao);
        END IF;
      EXCEPTION
        WHEN undefined_table THEN
          RAISE NOTICE 'Table inscricoes_crisma does not exist yet';
      END $$;
    `);

    // Criar tabela de status_controle e histórico se não existirem
    await pool.query(`
      DO $$ 
      BEGIN
        -- Criar a tabela de usuários se não existir
        CREATE TABLE IF NOT EXISTS usuarios (
          id SERIAL PRIMARY KEY,
          usuario VARCHAR(50) UNIQUE NOT NULL,
          senha VARCHAR(255) NOT NULL,
          nome VARCHAR(255) NOT NULL,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          ativo BOOLEAN DEFAULT true
        );

        -- Criar índices se não existirem
        CREATE INDEX IF NOT EXISTS idx_usuarios_usuario ON usuarios(usuario);
        CREATE INDEX IF NOT EXISTS idx_usuarios_ativo ON usuarios(ativo);

        -- Inserir usuário admin padrão se não existir
        IF NOT EXISTS (SELECT 1 FROM usuarios WHERE usuario = 'admin') THEN
          INSERT INTO usuarios (usuario, senha, nome) VALUES 
          ('admin', '$2b$10$zbTzMIFrqM.kgjfrDQqnFeHBTtu9fn6w/HM7wyWTQhB6bpMjVx5Iy', 'Administrador');
        END IF;

        -- Criar tabela de grupos/perfis de acesso se não existir
        CREATE TABLE IF NOT EXISTS grupos_acesso (
          id SERIAL PRIMARY KEY,
          nome VARCHAR(50) UNIQUE NOT NULL,
          descricao TEXT,
          permissoes TEXT[],
          ativo BOOLEAN DEFAULT true,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        -- Criar tabela de relacionamento usuário-grupo se não existir
        CREATE TABLE IF NOT EXISTS usuario_grupos (
          id SERIAL PRIMARY KEY,
          usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
          grupo_id INTEGER NOT NULL REFERENCES grupos_acesso(id) ON DELETE CASCADE,
          created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          UNIQUE(usuario_id, grupo_id)
        );

        -- Criar índices para grupos se não existirem
        CREATE INDEX IF NOT EXISTS idx_usuario_grupos_usuario ON usuario_grupos(usuario_id);
        CREATE INDEX IF NOT EXISTS idx_usuario_grupos_grupo ON usuario_grupos(grupo_id);
        CREATE INDEX IF NOT EXISTS idx_grupos_acesso_nome ON grupos_acesso(nome);
        CREATE INDEX IF NOT EXISTS idx_grupos_acesso_ativo ON grupos_acesso(ativo);

        -- Inserir grupos padrão se não existirem
        IF NOT EXISTS (SELECT 1 FROM grupos_acesso WHERE nome = 'admin') THEN
          INSERT INTO grupos_acesso (nome, descricao, permissoes) VALUES 
          ('admin', 'Administrador do Sistema', 
           ARRAY['usuarios.criar', 'usuarios.listar', 'usuarios.editar', 'usuarios.deletar', 
                 'inscricoes.criar', 'inscricoes.listar', 'inscricoes.editar', 'inscricoes.deletar',
                 'grupos.criar', 'grupos.listar', 'grupos.editar', 'grupos.deletar',
                 'sistema.configurar']),
          ('operador', 'Operador do Sistema', 
           ARRAY['inscricoes.criar', 'inscricoes.listar', 'inscricoes.editar', 
                 'usuarios.listar']),
          ('consulta', 'Apenas Consulta', 
           ARRAY['inscricoes.listar', 'usuarios.listar']);
        END IF;

        -- Associar usuário admin ao grupo admin se não estiver associado
        IF NOT EXISTS (
          SELECT 1 FROM usuario_grupos ug
          JOIN usuarios u ON ug.usuario_id = u.id
          JOIN grupos_acesso g ON ug.grupo_id = g.id
          WHERE u.usuario = 'admin' AND g.nome = 'admin'
        ) THEN
          INSERT INTO usuario_grupos (usuario_id, grupo_id) 
          SELECT u.id, g.id 
          FROM usuarios u, grupos_acesso g 
          WHERE u.usuario = 'admin' AND g.nome = 'admin';
        END IF;

        -- Criar a tabela de controle se não existir
        CREATE TABLE IF NOT EXISTS status_controle (
          id SERIAL PRIMARY KEY,
          inscricao_id INTEGER NOT NULL REFERENCES inscricoes_crisma(id),
          status VARCHAR(20) NOT NULL CHECK (status IN ('Em Andamento', 'Desistência', 'Concluído', '')),
          observacao TEXT,
          data_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          UNIQUE(inscricao_id)
        );

        -- Criar a tabela de histórico se não existir
        CREATE TABLE IF NOT EXISTS status_historico (
          id SERIAL PRIMARY KEY,
          inscricao_id INTEGER NOT NULL REFERENCES inscricoes_crisma(id),
          status VARCHAR(20) NOT NULL CHECK (status IN ('Em Andamento', 'Desistência', 'Concluído', '')),
          observacao TEXT,
          data_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        );

        -- Criar índice se não existir
        CREATE INDEX IF NOT EXISTS idx_status_inscricao ON status_controle(inscricao_id);
      EXCEPTION
        WHEN duplicate_table THEN
          NULL;
      END $$;
    `);

    // Remover colunas antigas de path se existirem
    await pool.query(`
      ALTER TABLE inscricoes_crisma 
      DROP COLUMN IF EXISTS documento_identidade_path,
      DROP COLUMN IF EXISTS certidao_batismo_path
    `);

    // Adicionar colunas para armazenar arquivos como BLOB
    await pool.query(`
      ALTER TABLE inscricoes_crisma 
      ADD COLUMN IF NOT EXISTS documento_identidade_data BYTEA,
      ADD COLUMN IF NOT EXISTS documento_identidade_nome VARCHAR(255),
      ADD COLUMN IF NOT EXISTS documento_identidade_tipo VARCHAR(100),
      ADD COLUMN IF NOT EXISTS documento_identidade_tamanho INTEGER,
      ADD COLUMN IF NOT EXISTS certidao_batismo_data BYTEA,
      ADD COLUMN IF NOT EXISTS certidao_batismo_nome VARCHAR(255),
      ADD COLUMN IF NOT EXISTS certidao_batismo_tipo VARCHAR(100),
      ADD COLUMN IF NOT EXISTS certidao_batismo_tamanho INTEGER
    `);

    console.log('✅ Estrutura do banco atualizada para BLOB!');
    return true;
  } catch (error) {
    console.error('❌ Erro ao atualizar estrutura do banco:', error);
    return false;
  }
}

// Iniciar servidor
app.listen(PORT, async () => {
  console.log(`🚀 Servidor rodando na porta ${PORT}`);
  console.log(`📊 API disponível em http://localhost:${PORT}/api`);
  console.log(`🔗 Teste: http://localhost:${PORT}/api/test`);
  console.log(`📋 Verificar tabela: http://localhost:${PORT}/api/check-table`);
  console.log(`📎 Upload de arquivos: ${uploadDir}`);
  console.log('');
  console.log('🔐 APIs de Autenticação:');
  console.log(`   POST /api/login - Login de usuário`);
  console.log(`   GET /api/verify-token - Verificar token JWT`);
  console.log('');
  console.log('👥 APIs de Usuários (requer permissões):');
  console.log(`   POST /api/usuarios - Criar usuário (usuarios.criar)`);
  console.log(`   GET /api/usuarios - Listar usuários (usuarios.listar)`);
  console.log(`   GET /api/usuarios/:id - Obter usuário por ID (usuarios.listar)`);
  console.log(`   PUT /api/usuarios/:id - Atualizar usuário (usuarios.editar)`);
  console.log(`   DELETE /api/usuarios/:id - Deletar usuário (usuarios.deletar)`);
  console.log(`   GET /api/usuarios/:id/grupos - Obter grupos do usuário (usuarios.listar)`);
  console.log(`   POST /api/usuarios/:userId/grupos/:grupoId - Adicionar usuário ao grupo (usuarios.editar)`);
  console.log(`   DELETE /api/usuarios/:userId/grupos/:grupoId - Remover usuário do grupo (usuarios.editar)`);
  console.log('');
  console.log('🏷️ APIs de Grupos/Perfis (requer permissões):');
  console.log(`   GET /api/grupos - Listar grupos (grupos.listar)`);
  console.log(`   GET /api/grupos/:id - Obter grupo por ID (grupos.listar)`);
  console.log(`   POST /api/grupos - Criar grupo (grupos.criar)`);
  console.log(`   PUT /api/grupos/:id - Atualizar grupo (grupos.editar)`);
  console.log(`   DELETE /api/grupos/:id - Deletar grupo (grupos.deletar)`);
  console.log(`   GET /api/permissoes - Listar permissões disponíveis (grupos.listar)`);
  console.log('');
  console.log('📝 Usuário padrão: admin / senha: admin123 (grupo: admin)');
  console.log('');
  
  // Atualizar estrutura do banco automaticamente
  await atualizarEstruturaBanco();
});

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('🛑 Encerrando servidor...');
  await pool.end();
  process.exit(0);
});