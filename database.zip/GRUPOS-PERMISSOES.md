# Sistema de Grupos e Permissões

## Visão Geral

O sistema implementa controle de acesso baseado em grupos/perfis. Cada usuário pode pertencer a múltiplos grupos, e cada grupo possui um conjunto de permissões específicas.

## Grupos Padrão

### 1. Admin (Administrador do Sistema)
**Permissões:**
- `usuarios.criar` - Criar usuários
- `usuarios.listar` - Listar usuários
- `usuarios.editar` - Editar usuários
- `usuarios.deletar` - Deletar usuários
- `inscricoes.criar` - Criar inscrições
- `inscricoes.listar` - Listar inscrições
- `inscricoes.editar` - Editar inscrições
- `inscricoes.deletar` - Deletar inscrições
- `grupos.criar` - Criar grupos
- `grupos.listar` - Listar grupos
- `grupos.editar` - Editar grupos
- `grupos.deletar` - Deletar grupos
- `sistema.configurar` - Configurar sistema

### 2. Operador (Operador do Sistema)
**Permissões:**
- `inscricoes.criar` - Criar inscrições
- `inscricoes.listar` - Listar inscrições
- `inscricoes.editar` - Editar inscrições
- `usuarios.listar` - Listar usuários

### 3. Consulta (Apenas Consulta)
**Permissões:**
- `inscricoes.listar` - Listar inscrições
- `usuarios.listar` - Listar usuários

## APIs de Grupos

### Listar Grupos
**GET** `/api/grupos`

**Permissão necessária:** `grupos.listar`

**Resposta:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "nome": "admin",
      "descricao": "Administrador do Sistema",
      "permissoes": ["usuarios.criar", "usuarios.listar", "..."],
      "ativo": true,
      "created_at": "2024-12-07T10:00:00.000Z",
      "updated_at": "2024-12-07T10:00:00.000Z"
    }
  ]
}
```

### Obter Grupo por ID
**GET** `/api/grupos/:id`

**Permissão necessária:** `grupos.listar`

### Criar Grupo
**POST** `/api/grupos`

**Permissão necessária:** `grupos.criar`

**Body:**
```json
{
  "nome": "novo_grupo",
  "descricao": "Descrição do novo grupo",
  "permissoes": ["inscricoes.listar", "usuarios.listar"]
}
```

### Atualizar Grupo
**PUT** `/api/grupos/:id`

**Permissão necessária:** `grupos.editar`

**Body (todos os campos são opcionais):**
```json
{
  "nome": "novo_nome",
  "descricao": "Nova descrição",
  "permissoes": ["inscricoes.criar", "inscricoes.listar"],
  "ativo": false
}
```

### Deletar Grupo
**DELETE** `/api/grupos/:id`

**Permissão necessária:** `grupos.deletar`

> **Nota:** Não é possível deletar os grupos padrão (admin, operador, consulta).

## APIs de Gestão Usuário-Grupo

### Obter Grupos de um Usuário
**GET** `/api/usuarios/:id/grupos`

**Permissão necessária:** `usuarios.listar`

**Resposta:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "nome": "admin",
      "descricao": "Administrador do Sistema",
      "permissoes": ["usuarios.criar", "usuarios.listar", "..."],
      "vinculado_em": "2024-12-07T10:00:00.000Z"
    }
  ]
}
```

### Adicionar Usuário a um Grupo
**POST** `/api/usuarios/:userId/grupos/:grupoId`

**Permissão necessária:** `usuarios.editar`

### Remover Usuário de um Grupo
**DELETE** `/api/usuarios/:userId/grupos/:grupoId`

**Permissão necessária:** `usuarios.editar`

## API de Permissões

### Listar Permissões Disponíveis
**GET** `/api/permissoes`

**Permissão necessária:** `grupos.listar`

**Resposta:**
```json
{
  "success": true,
  "data": [
    {
      "categoria": "usuarios",
      "permissoes": ["usuarios.criar", "usuarios.listar", "usuarios.editar", "usuarios.deletar"]
    },
    {
      "categoria": "inscricoes",
      "permissoes": ["inscricoes.criar", "inscricoes.listar", "inscricoes.editar", "inscricoes.deletar"]
    },
    {
      "categoria": "grupos",
      "permissões": ["grupos.criar", "grupos.listar", "grupos.editar", "grupos.deletar"]
    },
    {
      "categoria": "sistema",
      "permissoes": ["sistema.configurar"]
    }
  ]
}
```

## Login com Permissões

Quando um usuário faz login, as permissões são incluídas na resposta:

**POST** `/api/login`

**Resposta:**
```json
{
  "success": true,
  "message": "Login realizado com sucesso",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "usuario": {
      "id": 1,
      "usuario": "admin",
      "nome": "Administrador",
      "permissions": ["usuarios.criar", "usuarios.listar", "usuarios.editar", "..."]
    }
  }
}
```

## Verificação de Token com Permissões

**GET** `/api/verify-token`

**Resposta:**
```json
{
  "success": true,
  "message": "Token válido",
  "data": {
    "usuario": {
      "id": 1,
      "usuario": "admin",
      "nome": "Administrador",
      "permissions": ["usuarios.criar", "usuarios.listar", "usuarios.editar", "..."]
    }
  }
}
```

## Como Usar no Frontend

### 1. Verificar Permissões
```javascript
// Verificar se o usuário tem uma permissão específica
function hasPermission(permission) {
  const user = localStorage.getItem('user');
  if (!user) return false;
  
  const userData = JSON.parse(user);
  return userData.permissions && userData.permissions.includes(permission);
}

// Exemplo de uso
if (hasPermission('usuarios.criar')) {
  // Mostrar botão de criar usuário
}
```

### 2. Proteger Rotas/Componentes
```javascript
// Componente React exemplo
function UserManagement() {
  const canCreateUsers = hasPermission('usuarios.criar');
  const canEditUsers = hasPermission('usuarios.editar');
  const canDeleteUsers = hasPermission('usuarios.deletar');
  
  return (
    <div>
      {canCreateUsers && <button>Criar Usuário</button>}
      {canEditUsers && <button>Editar</button>}
      {canDeleteUsers && <button>Deletar</button>}
    </div>
  );
}
```

## Estrutura do Banco de Dados

### Tabela grupos_acesso
```sql
CREATE TABLE grupos_acesso (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(50) UNIQUE NOT NULL,
    descricao TEXT,
    permissoes TEXT[],
    ativo BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Tabela usuario_grupos
```sql
CREATE TABLE usuario_grupos (
    id SERIAL PRIMARY KEY,
    usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
    grupo_id INTEGER NOT NULL REFERENCES grupos_acesso(id) ON DELETE CASCADE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(usuario_id, grupo_id)
);
```

## Códigos de Erro

- **401** - Token inválido ou ausente
- **403** - Permissão insuficiente (ex: "Permissão necessária: usuarios.criar")
- **400** - Dados inválidos
- **404** - Recurso não encontrado
- **500** - Erro interno do servidor